function outputs = zrotFromTrans(homTransform)
        outputs = 1;
        xy = [homTransform(1,1), homTransform(2,1)];
        
        x = xy(1);
        y = xy(2);

        %regular cases
         if xy(1)>0 && y>0 % +x  +y
             outputs = acos(abs(xy(1)));
         end
         
         if xy(1)<0 && y>0 %-x +y
             outputs = pi/2 + asin(abs(xy(1)));
         end
         
         if xy(1)<0 && y<0 %-x -y
             outputs = pi + acos(abs(xy(1)));
         end

         if xy(1)>0 && y<0 %+x -y
             outputs = 1.5*pi + asin(abs(xy(1)));
         end

        %% edge cases where x or y = 0 or 1. 
        
        if xy(1) == 0 && y ==1
            outputs = pi/2;
        end

        if xy(1) == 1 && y ==0
            outputs = 0
        end

        if xy(1) == -1 && y ==0
            outputs = pi
        end

        if xy(1) == 0 && y == -1
            outputs = 1.5*pi
        end
end% end zrotfromtrans